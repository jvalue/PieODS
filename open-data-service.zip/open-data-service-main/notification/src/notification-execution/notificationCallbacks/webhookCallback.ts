export default interface WebhookCallback {
  location: string
  message: string
  timestamp: Date
}
