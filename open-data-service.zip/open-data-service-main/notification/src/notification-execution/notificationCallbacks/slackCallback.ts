export default interface SlackCallback {
  text: string
}
