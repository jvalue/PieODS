export default interface Stats {
  durationInMilliSeconds: number
  startTimestamp: number
  endTimestamp: number
}
