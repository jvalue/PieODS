module.exports = {
  testEnvironment: 'node',
  testRunner: 'jest-circus/runner',
  roots: ['./src']
}
