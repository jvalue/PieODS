kubectl delete namespaces $1
