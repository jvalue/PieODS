package org.jvalue.ods.adapterservice.adapter.model;

import lombok.Value;

@Value
public class DataImportResponse {
  String data;
}
