package org.jvalue.ods.adapterservice.datasource.api.rest.v1;

public class Mappings {
  public static final String DATA_PATH = "/data";
  public static final String DATASOURCE_PATH = "/datasources";
  public static final String DATAIMPORT_PATH = "/imports";
  public static final String LATEST_PATH = "/latest";
}