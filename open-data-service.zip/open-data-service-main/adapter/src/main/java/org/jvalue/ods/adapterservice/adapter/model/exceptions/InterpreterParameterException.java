package org.jvalue.ods.adapterservice.adapter.model.exceptions;

public class InterpreterParameterException extends AdapterException {
  public InterpreterParameterException(String message) {
    super(message);
  }
}
