package org.jvalue.ods.adapterservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdapterServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(AdapterServiceApplication.class, args);
  }

}
