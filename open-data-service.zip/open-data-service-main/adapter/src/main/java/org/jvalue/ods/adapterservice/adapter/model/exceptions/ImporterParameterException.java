package org.jvalue.ods.adapterservice.adapter.model.exceptions;

public class ImporterParameterException extends AdapterException {
  public ImporterParameterException(String message) {
    super(message);
  }
}
